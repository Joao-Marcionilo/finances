default_data = """
    DRIVER={ODBC Driver 17 for SQL Server};
    SERVER=localhost;
    TRUSTED_CONNECTION=yes;
"""
